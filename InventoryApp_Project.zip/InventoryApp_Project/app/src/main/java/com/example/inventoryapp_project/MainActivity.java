package com.example.inventoryapp_project;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.*;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    InventoryAdapter adapter;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        db = new DatabaseHelper(this);
        db.createInventoryTable();

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 1);
        }

        loadItems();
    }

    private void loadItems() {
        Cursor c = db.getAllItems();
        ArrayList<Item> list = new ArrayList<>();

        while (c.moveToNext()) {
            int id = c.getInt(0);
            String name = c.getString(1);
            int qty = c.getInt(2);
            list.add(new Item(id, name, qty));
        }

        adapter = new InventoryAdapter(list);
        recyclerView.setAdapter(adapter);
    }

    private void sendLowStockAlert(String itemName) {
        SmsUtil.sendSMS(this, "1234567890", "Low stock alert: " + itemName);
    }
}
